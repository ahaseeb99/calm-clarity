<?php
$config['db']['host'] = 'localhost';
$config['db']['name'] = 'demo';
$config['db']['user'] = 'root';
$config['db']['pass'] = '';
$config['db']['pre'] = 'qa_';
$config['db']['port'] = '';

$config['version'] = '4.6';
?>